head(Cigarette)

CigBox <- ggplot( Cigarette , aes( x=state, y = packpc ))
CigBox + geom_boxplot()+xlab("State") + ylab("Average number of packs of cigarettes per capita per year") + ggtitle("Average number of packs per capita by State")

MedCigAll <- Cigarette %>% group_by (year) %>% summarise (Med=median(packpc))


Cig85_95 <- filter(Cigarette, year %in% c(1985:1995))

ggplot(Cigarette,aes(x =avgprs, , y =  packpc, color= year))  + geom_point() + geom_smooth(method='lm') + xlab("Price") + ylab("Pack per Capita")

View(Cigarette)

ggplot(AdjCig,aes(x = AdjPrice, y = packpc , color= year))  + geom_point()+ geom_smooth(method='lm', se=TRUE) + xlab("Packs per Capita")  + ylab("Average Price")

cor.test(Cigarette$avgprs, Cigarette$packpc, method="pearson" , use= "complete.obs")

CigReg <- lm(packpc ~ avgprs , Cigarette)
summary(CigReg)

AdjCig <- mutate(Cigarette, AdjPrice = avgprs / cpi )

ggplot(AdjCig,aes(x = AdjPrice, y = packpc , color= year))  + geom_point()+ geom_smooth(method='lm', se=TRUE) + xlab("Packs per Capita")  + ylab("Average Price")

AdjCigReg <- lm(AdjPrice ~ packpc , AdjCig)
summary(AdjCigReg)

Cig1985 <- filter(Cigarette, year == 1985)

Cig1995 <- filter(Cigarette, year ==1995)

Cig1985_1995PackpcT <- t.test(Cig1985$packpc, Cig1995$packpc, paired=TRUE)
View(Cig1985_1995PackpcT)

CigIncomeT <- lm(income~packpc,Cigarette)
summary(CigIncomeT)

